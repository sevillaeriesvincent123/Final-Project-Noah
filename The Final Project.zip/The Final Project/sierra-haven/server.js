'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const config = require('./lib/config');
const { query, tx } = require('./lib/db');
const { migrate } = require('./lib/migrate');
const collections = require('./lib/collections');
const storage = require('./lib/storage');
const auth = require('./lib/auth');

const app = express();
app.set('trust proxy', 1);
app.disable('x-powered-by');
// Walang CSP: ang index.html ay may inline scripts (document.write router).
app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false, crossOriginResourcePolicy: { policy: 'cross-origin' } }));
app.use(express.json({ limit: '2mb' }));
app.use(auth.attachUser);

const wrap = fn => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
const { requireAuth, requireAdmin } = auth;

// =====================================================================
//  AUTH
// =====================================================================
const authLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 40, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again in a few minutes.' } });

app.post('/api/auth/signup', authLimiter, wrap(async (req, res) => {
  const v = auth.validateSignup(req.body || {});
  if (v.error) return res.status(400).json({ error: v.error });
  const dup = await query('select 1 from app_users where lower(email) = $1', [v.email]);
  if (dup.rowCount) return res.status(409).json({ error: 'That email is already registered. Please sign in instead.' });
  const row = await auth.createUser({ ...v, role: 'client' });
  res.status(201).json({ token: auth.signToken(row), user: auth.publicUser(row) });
}));

app.post('/api/auth/login', authLimiter, wrap(async (req, res) => {
  const email = String(req.body.email || '').trim().toLowerCase();
  const password = String(req.body.password || '');
  const { rows } = await query('select * from app_users where lower(email) = $1', [email]);
  const row = rows[0];
  // laging mag-compare para pantay ang oras ng response
  const ok = await auth.bcrypt.compare(password, row ? row.password_hash : '$2a$10$invalidinvalidinvalidinvalidinvalidinvalidinvalidinvalidi');
  if (!row || !ok) return res.status(401).json({ error: 'Incorrect email or password.' });
  await query(`update leases set tenant_id = $1 where tenant_id is null and lower(email) = lower($2)`, [row.id, row.email]);
  res.json({ token: auth.signToken(row), user: auth.publicUser(row) });
}));

app.get('/api/auth/me', requireAuth, (req, res) => res.json({ user: auth.publicUser(req.profile) }));

app.patch('/api/auth/me', requireAuth, wrap(async (req, res) => {
  const fullName = String(req.body.fullName ?? req.profile.full_name).trim().replace(/\s+/g, ' ');
  const phone = String(req.body.phone ?? req.profile.phone).trim();
  const location = String(req.body.location ?? req.profile.location).trim();
  if (fullName.length < 2 || fullName.length > 100 || phone.length > 30 || location.length > 160) return res.status(400).json({ error: 'Invalid profile details.' });
  const { rows } = await query(
    'update app_users set full_name=$2, phone=$3, location=$4, updated_at=now() where id=$1 returning *',
    [req.user.id, fullName, phone, location]);
  res.json({ user: auth.publicUser(rows[0]) });
}));

// =====================================================================
//  BOOT  -  lahat ng data na kailangan ng page, naka-key gaya ng dating localStorage keys
// =====================================================================
const KEY = {
  properties: 'haven-property-listings', agents: 'haven-agents', applications: 'haven-applications',
  leases: 'haven-leases', maintenance: 'haven-maintenance', outbox: 'haven-application-email-outbox',
  tech: 'haven-maintenance-technician-availability', roster: 'haven-maintenance-technicians', users: 'haven-users', adminInquiries: 'haven-inquiries',
  interests: 'sierra-haven-property-interests', rewards: 'sierra-haven-home-rewards', tenant: 'sierra-haven-tenant-demo'
};
const TENANT_STATUS_OUT = { Open: 'Submitted', 'In Progress': 'In progress', Completed: 'Completed' };
const dateLabel = d => new Intl.DateTimeFormat('en', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date(d));

async function getState(userId, key) {
  const { rows } = await query('select value from user_state where user_id = $1 and key = $2', [userId, key]);
  return rows[0] ? rows[0].value : null;
}
async function setState(userId, key, value) {
  await query(
    `insert into user_state (user_id, key, value) values ($1,$2,$3)
     on conflict (user_id, key) do update set value = excluded.value, updated_at = now()`,
    [userId, key, JSON.stringify(value)]);
}

function userRecord(row, leaseCount) {
  return { id: row.id, name: row.full_name, email: row.email, phone: row.phone || '', location: row.location || '',
    role: row.role === 'admin' ? 'Admin' : 'Client', joined: String(row.created_at instanceof Date ? row.created_at.toISOString() : row.created_at).slice(0, 10),
    leases: leaseCount || 0 };
}

function pickLease(leases) {
  const rank = { Active: 0, Expiring: 1, Pending: 2, Expired: 3 };
  return leases.slice().sort((a, b) => (rank[a.status] ?? 9) - (rank[b.status] ?? 9))[0] || null;
}

async function tenantComposite(user, leases) {
  const rows = (await query(
    `select * from maintenance_requests where owner_id = $1 order by created_at asc`, [user.id])).rows;
  const state = (await getState(user.id, 'tenant')) || {};
  const lease = pickLease(leases);
  const leaseStatusDefault = lease && lease.status === 'Pending' ? 'Active' : 'Active';
  return {
    requests: rows.map(r => ({
      id: r.id, category: r.issue_type, description: r.description || r.title,
      date: dateLabel(r.created_at), status: TENANT_STATUS_OUT[r.status] || 'Submitted',
      assignee: r.assignee, priority: r.priority
    })),
    activities: Array.isArray(state.activities) ? state.activities : [],
    notifications: Array.isArray(state.notifications) ? state.notifications : [],
    paymentMethods: Array.isArray(state.paymentMethods) ? state.paymentMethods : [],
    leaseStatus: state.leaseStatus || leaseStatusDefault,
    renewalRequestedOn: state.renewalRequestedOn || ''
  };
}

app.get('/api/boot', wrap(async (req, res) => {
  const user = req.user || null;
  const data = {};
  const isAdmin = user && user.role === 'admin';

  const props = await collections.list('properties', user);
  data[KEY.properties] = isAdmin ? props : props.map(({ units, occupied, ...rest }) => rest);

  let lease = null;
  if (isAdmin) {
    const names = ['agents', 'applications', 'leases', 'maintenance', 'outbox'];
    const lists = await Promise.all(names.map(n => collections.list(n, user)));
    names.forEach((n, i) => { data[KEY[n]] = lists[i]; });
    data[KEY.adminInquiries] = await collections.list('inquiries', user);
    const settings = Object.fromEntries((await query(`select key, value from app_settings`)).rows.map(r => [r.key, r.value]));
    data[KEY.tech] = settings['technician-availability'] || {};
    data[KEY.roster] = Array.isArray(settings['technician-roster']) ? settings['technician-roster'] : [];
    const counts = (await query(`select tenant_id, count(*)::int as n from leases where tenant_id is not null group by tenant_id`)).rows;
    const byUser = Object.fromEntries(counts.map(c => [c.tenant_id, c.n]));
    data[KEY.users] = (await query('select * from app_users order by created_at asc')).rows.map(r => userRecord(r, byUser[r.id]));
  } else if (user) {
    const leases = await collections.list('leases', user);
    lease = pickLease(leases);
    data[KEY.interests] = await collections.list('inquiries', user);
    data[KEY.rewards] = (await getState(user.id, 'rewards')) || undefined;
    data[KEY.tenant] = await tenantComposite(user, leases);
    // properties ng lease (para sa larawan / detalye ng tinitirhan)
  }
  Object.keys(data).forEach(k => data[k] === undefined && delete data[k]);
  res.json({ user: user ? auth.publicUser(req.profile) : null, lease, data, site: { supportEmail: config.supportEmail } });
}));

// =====================================================================
//  COLLECTIONS  (admin CRUD; client: sariling inquiries lang)
// =====================================================================
const FILE_KIND_BY_COLLECTION = { properties: 'property-image', applications: 'application-doc', leases: 'lease-contract', maintenance: 'maintenance-photo' };

app.get('/api/c/:name', requireAuth, wrap(async (req, res) => {
  const rows = await collections.list(req.params.name, req.user);
  if (!rows) return res.status(403).json({ error: 'Forbidden' });
  res.json(rows);
}));

app.put('/api/c/:name', requireAuth, wrap(async (req, res) => {
  const name = req.params.name;
  const saved = await collections.applyChanges(name, req.user, req.body || {}, req.profile);
  const kind = FILE_KIND_BY_COLLECTION[name];
  if (kind && Array.isArray(req.body.deletes)) {
    for (const id of req.body.deletes) await removeFilesByRef(kind, String(id)).catch(e => console.warn('[files] cleanup:', e.message));
  }
  res.json({ saved });
}));

// ---------- Users (admin) ----------
app.put('/api/users', requireAdmin, wrap(async (req, res) => {
  const { upserts = [], deletes = [] } = req.body || {};
  for (const u of upserts) {
    if (!u || !u.id) continue;
    const role = String(u.role || '').toLowerCase() === 'admin' ? 'admin' : 'client';
    if (u.id === req.user.id && role !== 'admin') return res.status(400).json({ error: 'You cannot remove your own admin access.' });
    await query(
      `update app_users set full_name = coalesce(nullif($2,''), full_name), phone = $3, location = $4, role = $5, updated_at = now() where id = $1`,
      [u.id, String(u.name || '').trim().slice(0, 100), String(u.phone || '').slice(0, 30), String(u.location || '').slice(0, 160), role]);
  }
  for (const id of deletes) {
    if (id === req.user.id) return res.status(400).json({ error: 'You cannot delete your own account.' });
    await query('delete from user_state where user_id = $1', [id]);
    await query('delete from app_users where id = $1', [id]);
  }
  res.json({ ok: true });
}));

// ---------- Settings (technician availability) ----------
const SETTING_KEYS = { 'technician-availability': 'object', 'technician-roster': 'array' };
app.put('/api/settings/:key', requireAdmin, wrap(async (req, res) => {
  const kind = SETTING_KEYS[req.params.key];
  if (!kind) return res.status(404).json({ error: 'Unknown setting' });
  const value = req.body ? req.body.value : null;
  const valid = kind === 'array' ? Array.isArray(value) : (value && typeof value === 'object' && !Array.isArray(value));
  if (!valid || JSON.stringify(value).length > 100000) return res.status(400).json({ error: 'Invalid data' });
  await query(
    `insert into app_settings (key, value) values ($1, $2)
     on conflict (key) do update set value = excluded.value, updated_at = now()`, [req.params.key, JSON.stringify(value)]);
  res.json({ ok: true });
}));

// ---------- Per-user state (rewards) ----------
app.put('/api/state/rewards', requireAuth, wrap(async (req, res) => {
  const v = req.body && req.body.value;
  if (!v || typeof v !== 'object' || Array.isArray(v) || JSON.stringify(v).length > 20000) return res.status(400).json({ error: 'Invalid data' });
  await setState(req.user.id, 'rewards', v);
  res.json({ ok: true });
}));

// =====================================================================
//  TENANT  (maintenance requests -> lumalabas sa admin, lease actions, personal state)
// =====================================================================
const ISSUE_MAP = { 'Doors and windows': 'Structural' };
app.put('/api/tenant/state', requireAuth, wrap(async (req, res) => {
  const body = req.body || {};
  const newRequests = Array.isArray(body.newRequests) ? body.newRequests.slice(0, 20) : [];
  const state = body.state && typeof body.state === 'object' ? body.state : null;
  const profile = req.profile;
  const leases = await collections.list('leases', req.user);
  const lease = pickLease(leases);

  for (const r of newRequests) {
    if (!r || typeof r.id !== 'string' || !r.id || r.id.length > 80) continue;
    const exists = await query('select 1 from maintenance_requests where id = $1', [r.id]);
    if (exists.rowCount) continue;
    const description = String(r.description || '').trim().slice(0, 500);
    const category = String(r.category || 'Other').slice(0, 60);
    if (!description) continue;
    const issueType = ISSUE_MAP[category] || (['Plumbing', 'Electrical', 'Appliance', 'HVAC', 'Structural', 'Pest control', 'Cleaning'].includes(category) ? category : 'Other');
    await query(
      `insert into maintenance_requests (id, owner_id, title, property, unit, reported, issue_type, priority, assignee, status, description, data)
       values ($1,$2,$3,$4,$5,current_date,$6,'Medium','Unassigned','Open',$7,$8)`,
      [r.id, req.user.id, `${category}: ${description}`.slice(0, 120), lease ? lease.property : '', lease ? lease.unit : '',
        issueType, description, JSON.stringify({ source: 'tenant', tenantName: profile.full_name, tenantEmail: profile.email, tenantPhone: profile.phone, category })]);
  }

  if (state) {
    const clean = {
      activities: (Array.isArray(state.activities) ? state.activities : []).slice(0, 100),
      notifications: (Array.isArray(state.notifications) ? state.notifications : []).slice(0, 100),
      paymentMethods: (Array.isArray(state.paymentMethods) ? state.paymentMethods : []).slice(0, 10),
      leaseStatus: ['Active', 'Pending Renewal', 'Terminated'].includes(state.leaseStatus) ? state.leaseStatus : 'Active',
      renewalRequestedOn: String(state.renewalRequestedOn || '').slice(0, 40)
    };
    const prev = (await getState(req.user.id, 'tenant')) || {};
    await setState(req.user.id, 'tenant', clean);
    // Lease actions -> makikita ng admin
    if (lease && clean.leaseStatus !== (prev.leaseStatus || 'Active')) {
      const label = clean.leaseStatus === 'Pending Renewal' ? 'renewal' : clean.leaseStatus === 'Terminated' ? 'termination' : '';
      if (label) {
        const patch = clean.leaseStatus === 'Pending Renewal'
          ? { renewalRequestedOn: new Date().toISOString().slice(0, 10) }
          : { terminationRequestedOn: new Date().toISOString().slice(0, 10) };
        await query(
          `update leases set renewal_status = case when $2 = 'renewal' then 'Requested' else renewal_status end,
             data = data || $3::jsonb, updated_at = now() where id = $1`, [lease.id, label, JSON.stringify(patch)]);
        await query(
          `insert into email_outbox (id, recipient, subject, message, data) values ($1,$2,$3,$4,$5)`,
          [`tenant-${crypto.randomUUID()}`, 'admin', `Lease ${label} request: ${profile.full_name}`,
            `${profile.full_name} (${profile.email}) requested lease ${label} for ${lease.property} ${lease.unit}.`,
            JSON.stringify({ createdAt: new Date().toLocaleString('en-US'), kind: 'tenant-lease-request' })]);
      }
    }
  }
  res.json({ ok: true });
}));

// =====================================================================
//  FILES  (Supabase Storage)
// =====================================================================
const FILE_KINDS = {
  'property-image': { bucket: storage.PUBLIC, max: 10, image: true, who: 'admin' },
  'application-doc': { bucket: storage.PRIVATE, max: 10, who: 'admin' },
  'lease-contract': { bucket: storage.PRIVATE, max: 20, who: 'admin' },
  'maintenance-photo': { bucket: storage.PRIVATE, max: 8, image: true, who: 'admin-or-owner' }
};
const safeName = n => String(n || 'file').replace(/[^\w.\- ()]+/g, '_').slice(0, 120) || 'file';

async function canTouchRef(user, kind, refId) {
  if (user.role === 'admin') return true;
  if (kind === 'maintenance-photo') {
    const r = await query('select 1 from maintenance_requests where id = $1 and owner_id = $2', [refId, user.id]);
    return r.rowCount > 0;
  }
  return false;
}
async function canReadFile(user, f) {
  if (user.role === 'admin') return true;
  if (f.kind === 'maintenance-photo') return canTouchRef(user, f.kind, f.ref_id);
  if (f.kind === 'lease-contract') {
    const r = await query('select 1 from leases where id = $1 and (tenant_id = $2 or lower(email) = lower($3))', [f.ref_id, user.id, user.email]);
    return r.rowCount > 0;
  }
  return f.kind === 'property-image';
}
async function removeFilesByRef(kind, refId) {
  const { rows } = await query('delete from files where kind = $1 and ref_id = $2 returning bucket, path', [kind, refId]);
  for (const f of rows) await storage.driver.remove(f.bucket, f.path);
}
const fileOut = f => ({ id: f.id, name: f.name, type: f.mime_type, size: f.size, url: f.public_url || '' });

app.post('/api/files', requireAuth, express.raw({ type: () => true, limit: '26mb' }), wrap(async (req, res) => {
  const kind = String(req.query.kind || '');
  const refId = String(req.query.ref || '').slice(0, 120);
  const cfg = FILE_KINDS[kind];
  if (!cfg || !refId) return res.status(400).json({ error: 'Invalid upload request.' });
  if (!(await canTouchRef(req.user, kind, refId))) {
    return res.status(403).json({ error: 'You are not allowed to upload this file.' });
  }
  const buffer = req.body;
  if (!Buffer.isBuffer(buffer) || !buffer.length) return res.status(400).json({ error: 'The file is empty.' });
  if (buffer.length > cfg.max * 1024 * 1024) return res.status(413).json({ error: `File must be ${cfg.max} MB or smaller.` });
  const mime = String(req.headers['content-type'] || 'application/octet-stream').split(';')[0].trim().toLowerCase();
  if (cfg.image && !/^image\/(png|jpe?g|gif|webp|avif|heic|heif)$/.test(mime)) return res.status(400).json({ error: 'Please choose an image file (JPG, PNG, WEBP).' });
  let name = 'file';
  try { name = safeName(decodeURIComponent(String(req.headers['x-file-name'] || 'file'))); } catch (_) { name = 'file'; }

  const filePath = `${kind}/${refId.replace(/[^\w-]+/g, '_')}/${Date.now()}-${crypto.randomBytes(4).toString('hex')}-${name.replace(/\s+/g, '_')}`;
  await storage.driver.put(cfg.bucket, filePath, buffer, mime);
  const publicUrl = cfg.bucket === storage.PUBLIC ? storage.driver.publicUrl(cfg.bucket, filePath) : '';
  const { rows } = await query(
    `insert into files (kind, ref_id, bucket, path, name, mime_type, size, public_url, uploaded_by)
     values ($1,$2,$3,$4,$5,$6,$7,$8,$9) returning *`,
    [kind, refId, cfg.bucket, filePath, name, mime, buffer.length, publicUrl, req.user.id]);
  if (kind === 'lease-contract') {
    // isang contract lang kada lease: tanggalin ang mga lumang bersyon
    const old = await query('delete from files where kind = $1 and ref_id = $2 and id <> $3 returning bucket, path', [kind, refId, rows[0].id]);
    for (const f of old.rows) await storage.driver.remove(f.bucket, f.path);
  }
  res.status(201).json(fileOut(rows[0]));
}));

async function sendFile(res, f) {
  const buffer = await storage.driver.get(f.bucket, f.path);
  const inline = /^(image\/|application\/pdf)/.test(f.mime_type);
  res.set({
    'Content-Type': f.mime_type,
    'Content-Length': buffer.length,
    'Content-Disposition': `${inline ? 'inline' : 'attachment'}; filename*=UTF-8''${encodeURIComponent(f.name)}`,
    'Content-Security-Policy': 'sandbox',
    'Cache-Control': 'private, max-age=300',
    'X-File-Name': encodeURIComponent(f.name)
  });
  res.send(buffer);
}

app.get('/api/files/by-ref/:kind/:ref', requireAuth, wrap(async (req, res) => {
  const { rows } = await query('select * from files where kind = $1 and ref_id = $2 order by created_at desc limit 1', [req.params.kind, req.params.ref]);
  if (!rows[0]) return res.status(404).json({ error: 'File not found.' });
  if (!(await canReadFile(req.user, rows[0]))) return res.status(403).json({ error: 'Forbidden' });
  await sendFile(res, rows[0]);
}));

app.get('/api/files/:id', requireAuth, wrap(async (req, res) => {
  if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(404).json({ error: 'File not found.' });
  const { rows } = await query('select * from files where id = $1', [req.params.id]);
  if (!rows[0]) return res.status(404).json({ error: 'File not found.' });
  if (!(await canReadFile(req.user, rows[0]))) return res.status(403).json({ error: 'Forbidden' });
  await sendFile(res, rows[0]);
}));

app.delete('/api/files/by-ref/:kind/:ref', requireAdmin, wrap(async (req, res) => {
  if (!FILE_KINDS[req.params.kind]) return res.status(404).json({ error: 'Unknown file kind' });
  await removeFilesByRef(req.params.kind, req.params.ref);
  res.json({ ok: true });
}));

app.delete('/api/files/:id', requireAdmin, wrap(async (req, res) => {
  if (!/^[0-9a-f-]{36}$/i.test(req.params.id)) return res.status(404).json({ error: 'File not found.' });
  const { rows } = await query('delete from files where id = $1 returning bucket, path', [req.params.id]);
  if (rows[0]) await storage.driver.remove(rows[0].bucket, rows[0].path);
  res.json({ ok: true });
}));

app.get('/api/health', wrap(async (_req, res) => {
  await query('select 1');
  res.json({ ok: true, storage: storage.driver.name });
}));

// =====================================================================
//  STATIC FRONTEND
// =====================================================================
if (storage.driver.name === 'local-disk') {
  app.use(`/uploads/${storage.PUBLIC}`, express.static(path.join(config.localUploadDir, storage.PUBLIC), { maxAge: '7d' }));
}
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'], index: 'index.html' }));
app.use('/api', (_req, res) => res.status(404).json({ error: 'Not found' }));

// eslint-disable-next-line no-unused-vars
app.use((err, req, res, _next) => {
  const status = err.status || (err.code === '23505' ? 409 : 500);
  if (status >= 500) console.error('[error]', req.method, req.url, err);
  // Sa development, ipakita ang totoong dahilan para madaling ma-debug (nakatago kapag NODE_ENV=production)
  res.status(status).json({
    error: status >= 500 ? 'Something went wrong on the server.' : err.message,
    ...(status >= 500 && !config.isProd ? { detail: String(err.message || err).slice(0, 300) } : {})
  });
});

// =====================================================================
//  START
// =====================================================================
async function start() {
  try {
    await migrate();
  } catch (e) {
    console.error('\n[startup] Hindi makakonekta sa database / hindi nagawa ang tables:');
    console.error('          ' + e.message);
    console.error('          Tingnan ang DATABASE_URL sa .env (README Step 2).\n');
    process.exit(1);
  }
  try {
    await storage.driver.init();
    console.log(`[storage] Using ${storage.driver.name}`);
  } catch (e) {
    console.warn(`[storage] ${e.message}\n          Gagana pa rin ang site pero hindi gagana ang file uploads hanggang maayos ito.`);
  }
  await auth.ensureAdmin().catch(e => console.warn('[auth] ensureAdmin:', e.message));
  app.listen(config.port, () => console.log(`SIERRA HAVEN running on http://localhost:${config.port}`));
}
if (require.main === module) start();
module.exports = { app, start };