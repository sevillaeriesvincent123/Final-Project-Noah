-- =====================================================================
-- SIERRA HAVEN - database schema
-- Idempotent: ligtas patakbuhin nang paulit-ulit (auto-run sa bawat start
-- ng server sa pamamagitan ng lib/migrate.js).
-- =====================================================================

-- Sariling schema para hindi makabangga sa anumang table na meron na sa project mo (hal. "properties").
-- Makikita mo ito sa Supabase: Table Editor -> schema dropdown -> sierra_haven
create schema if not exists sierra_haven;
set search_path to sierra_haven, public;

-- ---------- USERS (tenants / clients / admins) ----------
create table if not exists app_users (
  id            uuid primary key default gen_random_uuid(),
  email         text not null,
  password_hash text not null,
  full_name     text not null,
  phone         text not null default '',
  location      text not null default '',
  role          text not null default 'client',
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);
create unique index if not exists app_users_email_lower_idx on app_users (lower(email));

-- ---------- PROPERTIES (bahay, lupa, condo, etc. na ina-upload ng admin) ----------
create table if not exists properties (
  id            text primary key,
  name          text not null,
  location      text not null default '',
  listing_type  text not null default 'For Rent',
  type          text not null default 'House & Lot',
  status        text not null default 'Active',
  units         integer not null default 1,
  occupied      integer not null default 0,
  rent          numeric not null default 0,
  price         numeric not null default 0,
  bedrooms      numeric,
  bathrooms     numeric,
  area          numeric,
  lot_area      numeric,
  description   text not null default '',
  image_url     text not null default '',
  images        jsonb not null default '[]'::jsonb,
  panorama_url  text not null default '',
  data          jsonb not null default '{}'::jsonb,
  created_by    uuid,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------- AGENTS ----------
create table if not exists agents (
  id                  text primary key,
  name                text not null,
  email               text not null default '',
  phone               text not null default '',
  team                text not null default '',
  assigned_properties integer not null default 0,
  closed_leases       integer not null default 0,
  rating              numeric not null default 0,
  workspace_role      text not null default 'Agent',
  status              text not null default 'Active',
  activity_date       date,
  activity            text not null default '',
  data                jsonb not null default '{}'::jsonb,
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- ---------- TENANT APPLICATIONS ----------
create table if not exists applications (
  id                 text primary key,
  owner_id           uuid,
  applicant          text not null,
  email              text not null default '',
  phone              text not null default '',
  property           text not null default '',
  unit               text not null default '',
  submitted          date,
  income             numeric not null default 0,
  status             text not null default 'Pending',
  background_status  text not null default 'Not started',
  background_notes   text not null default '',
  documents          jsonb not null default '[]'::jsonb,
  data               jsonb not null default '{}'::jsonb,
  created_at         timestamptz not null default now(),
  updated_at         timestamptz not null default now()
);

-- ---------- LEASES ----------
create table if not exists leases (
  id             text primary key,
  tenant_id      uuid,
  tenant         text not null,
  email          text not null default '',
  phone          text not null default '',
  property       text not null default '',
  unit           text not null default '',
  start_date     date,
  end_date       date,
  rent           numeric not null default 0,
  status         text not null default 'Pending',
  renewal_status text not null default 'Undecided',
  proposed_rent  numeric not null default 0,
  payments       jsonb not null default '[]'::jsonb,
  contract       jsonb,
  data           jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now(),
  updated_at     timestamptz not null default now()
);
create index if not exists leases_email_idx on leases (lower(email));

-- ---------- MAINTENANCE REQUESTS ----------
create table if not exists maintenance_requests (
  id              text primary key,
  owner_id        uuid,
  title           text not null,
  property        text not null default '',
  unit            text not null default '',
  reported        date,
  issue_type      text not null default 'Other',
  priority        text not null default 'Medium',
  assignee        text not null default 'Unassigned',
  status          text not null default 'Open',
  cost_estimate   numeric not null default 0,
  actual_cost     numeric not null default 0,
  completed_at    date,
  resolution_days numeric,
  description     text not null default '',
  photos          jsonb not null default '[]'::jsonb,
  data            jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now()
);

-- ---------- INQUIRIES / BOOKINGS (galing sa property catalog ng clients) ----------
create table if not exists inquiries (
  id            text primary key,
  user_id       uuid,
  name          text not null default '',
  contact_email text not null default '',
  phone         text not null default '',
  property_id   text not null default '',
  property_name text not null default '',
  location      text not null default '',
  price         text not null default '',
  status        text not null default 'Inquiry saved',
  date          text not null default '',
  data          jsonb not null default '{}'::jsonb,
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now()
);

-- ---------- EMAIL / NOTIFICATION OUTBOX (admin) ----------
create table if not exists email_outbox (
  id          text primary key,
  recipient   text not null default '',
  subject     text not null default '',
  message     text not null default '',
  data        jsonb not null default '{}'::jsonb,
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now()
);

-- ---------- PER-USER STATE (rewards, tenant preferences, notifications) ----------
create table if not exists user_state (
  user_id    uuid not null,
  key        text not null,
  value      jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now(),
  primary key (user_id, key)
);

-- ---------- APP SETTINGS (technician availability, etc.) ----------
create table if not exists app_settings (
  key        text primary key,
  value      jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

-- ---------- FILES (metadata; ang actual file ay nasa Supabase Storage) ----------
create table if not exists files (
  id           uuid primary key default gen_random_uuid(),
  kind         text not null,
  ref_id       text not null default '',
  bucket       text not null,
  path         text not null,
  name         text not null,
  mime_type    text not null default 'application/octet-stream',
  size         bigint not null default 0,
  public_url   text not null default '',
  uploaded_by  uuid,
  created_at   timestamptz not null default now()
);
create index if not exists files_ref_idx on files (kind, ref_id);

-- ---------- SECURITY ----------
-- Ang schema na ito ay hindi naka-expose sa Supabase Data API, at bukod doon:
-- Ang publishable key ay public. Kaya naka-ON ang Row Level Security sa LAHAT ng table
-- at walang policy para sa anon/authenticated => walang makakabasa gamit ang publishable key.
-- Ang backend lang (server-side) ang may access.
do $$
declare t text;
begin
  foreach t in array array['app_users','properties','agents','applications','leases',
    'maintenance_requests','inquiries','email_outbox','user_state','app_settings','files']
  loop
    execute format('alter table sierra_haven.%I enable row level security', t);
    if exists (select 1 from pg_roles where rolname = 'anon') then
      execute format('revoke all on table sierra_haven.%I from anon', t);
    end if;
    if exists (select 1 from pg_roles where rolname = 'authenticated') then
      execute format('revoke all on table sierra_haven.%I from authenticated', t);
    end if;
  end loop;
end $$;