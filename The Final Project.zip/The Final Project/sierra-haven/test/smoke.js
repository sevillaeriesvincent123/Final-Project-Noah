'use strict';
// Gamit:  BASE=http://localhost:3000 ADMIN_EMAIL=... ADMIN_PASSWORD=... node test/smoke.js
const BASE = process.env.BASE || 'http://localhost:3111';
const ADMIN = { email: process.env.ADMIN_EMAIL || 'admin@test.com', password: process.env.ADMIN_PASSWORD || 'Admin12345' };
let pass = 0, fail = 0;
const ok = (cond, label, extra) => { if (cond) { pass++; console.log('  ok   ', label); } else { fail++; console.log('  FAIL ', label, extra !== undefined ? JSON.stringify(extra) : ''); } };

async function call(method, path, { token, body, raw, headers } = {}) {
  const h = { ...(headers || {}) };
  if (token) h.Authorization = `Bearer ${token}`;
  let payload;
  if (raw) payload = raw; else if (body !== undefined) { h['Content-Type'] = 'application/json'; payload = JSON.stringify(body); }
  const res = await fetch(BASE + path, { method, headers: h, body: payload });
  const ct = res.headers.get('content-type') || '';
  const data = ct.includes('json') ? await res.json() : Buffer.from(await res.arrayBuffer());
  return { status: res.status, data, res };
}
const rand = Math.random().toString(36).slice(2, 8);

(async () => {
  console.log('AUTH');
  let r = await call('POST', '/api/auth/signup', { body: { fullName: 'A', email: 'bad', password: '1' } });
  ok(r.status === 400, 'signup validation rejects bad input', r.data);
  const tenantEmail = `juan.${rand}@example.com`;
  r = await call('POST', '/api/auth/signup', { body: { fullName: 'Juan Dela Cruz', email: tenantEmail, password: 'Password123', phone: '0917 123 4567', location: 'Quezon City' } });
  ok(r.status === 201 && r.data.token, 'signup creates tenant account');
  const T = r.data.token; const tenantId = r.data.user.id;
  ok(r.data.user.role === 'client' && r.data.user.fullName === 'Juan Dela Cruz', 'tenant has real name + role client');
  r = await call('POST', '/api/auth/signup', { body: { fullName: 'Juan Dela Cruz', email: tenantEmail.toUpperCase(), password: 'Password123', phone: '0917 123 4567' } });
  ok(r.status === 409, 'duplicate email rejected (case-insensitive)');
  r = await call('POST', '/api/auth/login', { body: { email: tenantEmail, password: 'wrong-pass' } });
  ok(r.status === 401, 'wrong password rejected');
  r = await call('POST', '/api/auth/login', { body: ADMIN });
  ok(r.status === 200 && r.data.user.role === 'admin', 'admin login');
  const A = r.data.token;
  r = await call('GET', '/api/auth/me', { token: T });
  ok(r.status === 200 && r.data.user.email === tenantEmail, 'me returns profile');
  r = await call('GET', '/api/auth/me');
  ok(r.status === 401, 'me without token = 401');

  console.log('PROPERTIES (admin uploads -> tenants see)');
  r = await call('GET', '/api/boot');
  ok(r.status === 200 && Array.isArray(r.data.data['haven-property-listings']), 'anonymous boot returns property list');
  const pid = `prop-${rand}`;
  r = await call('PUT', '/api/c/properties', { token: T, body: { upserts: [{ id: pid, name: 'Hack' }] } });
  ok(r.status === 403, 'tenant cannot create property');
  const prop = { id: pid, name: 'Bahay sa Tagaytay', location: 'Tagaytay, Cavite', listingType: 'For Sale', type: 'House & Lot', status: 'Active', units: 1, occupied: 0, rent: 0, price: 5500000, bedrooms: 3, bathrooms: 2, area: 120, lotArea: 250, description: 'Malamig na hangin', image: '', images: [], customField: 'keep-me' };
  r = await call('PUT', '/api/c/properties', { token: A, body: { upserts: [prop] } });
  ok(r.status === 200 && r.data.saved[0].name === 'Bahay sa Tagaytay', 'admin creates property');
  r = await call('PUT', '/api/c/properties', { token: A, body: { upserts: [{ id: `lot-${rand}`, name: 'Lupa sa Batangas', location: 'Batangas', listingType: 'For Sale', type: 'Lot / Land', status: 'Inactive', price: 1200000, units: 1, occupied: 0, rent: 0 }] } });
  r = await call('GET', '/api/boot', { token: T });
  const tProps = r.data.data['haven-property-listings'];
  ok(tProps.some(p => p.id === pid && p.price === 5500000 && p.customField === 'keep-me'), 'tenant sees active listing with all fields (incl. extra field)');
  ok(!tProps.some(p => p.id === `lot-${rand}`), 'tenant does NOT see inactive listing');
  ok(!('occupied' in tProps[0]), 'tenant boot hides occupancy numbers');
  r = await call('GET', '/api/boot', { token: A });
  ok(r.data.data['haven-property-listings'].some(p => p.id === `lot-${rand}`), 'admin sees inactive listing too');

  console.log('FILES');
  const png = Buffer.from('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg==', 'base64');
  r = await call('POST', `/api/files?kind=property-image&ref=${pid}`, { token: T, raw: png, headers: { 'Content-Type': 'image/png', 'X-File-Name': 'a.png' } });
  ok(r.status === 403, 'tenant cannot upload property image');
  r = await call('POST', `/api/files?kind=property-image&ref=${pid}`, { token: A, raw: Buffer.from('<script>alert(1)</script>'), headers: { 'Content-Type': 'text/html', 'X-File-Name': 'x.html' } });
  ok(r.status === 400, 'non-image rejected for property-image');
  r = await call('POST', `/api/files?kind=property-image&ref=${pid}`, { token: A, raw: png, headers: { 'Content-Type': 'image/png', 'X-File-Name': encodeURIComponent('bahay front.png') } });
  ok(r.status === 201 && r.data.url, 'admin uploads property image -> public url', r.data);
  const imgUrl = r.data.url;
  const pub = await fetch(BASE + imgUrl);
  ok(pub.status === 200 && (pub.headers.get('content-type') || '').includes('image/png'), 'public image URL is reachable without login');
  await call('PUT', '/api/c/properties', { token: A, body: { upserts: [{ ...prop, image: imgUrl, images: [imgUrl] }] } });
  r = await call('GET', '/api/boot');
  ok(r.data.data['haven-property-listings'].find(p => p.id === pid).image === imgUrl, 'image reflected for anonymous visitors');

  console.log('INQUIRIES / BOOKINGS');
  const inq = { id: `inq-${rand}`, propertyId: pid, propertyName: 'Bahay sa Tagaytay', location: 'Tagaytay, Cavite', price: '₱5,500,000', status: 'Inquiry saved', date: 'Oct 29, 2026', name: 'FAKE NAME', contactEmail: 'fake@x.com' };
  r = await call('PUT', '/api/c/inquiries', { token: T, body: { upserts: [inq] } });
  ok(r.status === 200, 'tenant saves inquiry');
  ok(r.data.saved[0].name === 'Juan Dela Cruz' && r.data.saved[0].contactEmail === tenantEmail && r.data.saved[0].phone === '0917 123 4567', 'inquiry carries REAL name/contact (client cannot spoof)', r.data.saved[0]);
  r = await call('GET', '/api/boot', { token: A });
  ok(r.data.data['haven-inquiries'].some(i => i.id === inq.id && i.name === 'Juan Dela Cruz'), 'admin sees inquiry with tenant name + contact');
  ok(r.data.data['haven-users'].some(u => u.email === tenantEmail && u.phone === '0917 123 4567' && u.location === 'Quezon City'), 'admin sees registered user with contact + location');
  const other = await call('POST', '/api/auth/signup', { body: { fullName: 'Maria Santos', email: `maria.${rand}@example.com`, password: 'Password123', phone: '09171234567' } });
  r = await call('PUT', '/api/c/inquiries', { token: other.data.token, body: { upserts: [{ ...inq, status: 'hijack' }] } });
  ok(r.status === 403, "another tenant cannot overwrite someone else's inquiry");
  r = await call('GET', '/api/boot', { token: other.data.token });
  ok(!(r.data.data['sierra-haven-property-interests'] || []).length, "other tenant sees none of Juan's inquiries");

  console.log('LEASE + TENANT DASHBOARD');
  const lid = `lease-${rand}`;
  r = await call('PUT', '/api/c/leases', { token: A, body: { upserts: [{ id: lid, tenant: 'Juan Dela Cruz', email: tenantEmail, property: 'Bahay sa Tagaytay', unit: 'Main', start: '2026-10-01', end: '2027-10-01', rent: 25000, status: 'Active', renewalStatus: 'Undecided', proposedRent: 0, payments: [{ id: 'p1', date: '2026-10-01', amount: 25000, note: 'October rent', status: 'Paid' }], contract: null }] } });
  ok(r.status === 200, 'admin creates lease for tenant email');
  r = await call('GET', '/api/boot', { token: T });
  ok(r.data.lease && r.data.lease.id === lid && r.data.lease.payments.length === 1, 'tenant boot returns own lease + payments');
  r = await call('GET', '/api/boot', { token: other.data.token });
  ok(!r.data.lease, "other tenant has no lease (no data leak)");
  r = await call('PUT', '/api/c/leases', { token: T, body: { upserts: [{ id: lid, tenant: 'x', rent: 1 }] } });
  ok(r.status === 403, 'tenant cannot edit lease directly');

  const reqId = `SH-${rand}-1`;
  r = await call('PUT', '/api/tenant/state', { token: T, body: { newRequests: [{ id: reqId, category: 'Plumbing', description: 'Tumutulo ang gripo sa kusina', date: 'Oct 29, 2026', status: 'Submitted' }], state: { activities: [{ text: 'Maintenance request submitted', date: 'Oct 29, 2026' }], notifications: [], paymentMethods: [], leaseStatus: 'Active', renewalRequestedOn: '' } } });
  ok(r.status === 200, 'tenant submits maintenance request');
  r = await call('GET', '/api/boot', { token: A });
  const m = r.data.data['haven-maintenance'].find(x => x.id === reqId);
  ok(m && m.property === 'Bahay sa Tagaytay' && m.issueType === 'Plumbing' && m.status === 'Open' && m.tenantName === 'Juan Dela Cruz', 'request appears in ADMIN maintenance with property + tenant name', m);
  await call('PUT', '/api/c/maintenance', { token: A, body: { upserts: [{ ...m, status: 'In Progress', assignee: 'Rapid Fix' }] } });
  r = await call('GET', '/api/boot', { token: T });
  const tr = r.data.data['sierra-haven-tenant-demo'].requests.find(x => x.id === reqId);
  ok(tr && tr.status === 'In progress', 'admin status change reflects on tenant dashboard', tr);
  ok(r.data.data['sierra-haven-tenant-demo'].activities.length === 1, 'tenant activity persisted');
  r = await call('PUT', '/api/tenant/state', { token: T, body: { newRequests: [], state: { activities: [], notifications: [], paymentMethods: [], leaseStatus: 'Pending Renewal', renewalRequestedOn: 'Oct 29, 2026' } } });
  r = await call('GET', '/api/boot', { token: A });
  ok(r.data.data['haven-leases'].find(l => l.id === lid).renewalStatus === 'Requested', 'tenant renewal request flags lease for admin');
  ok(r.data.data['haven-application-email-outbox'].some(o => /renewal/.test(o.subject)), 'admin outbox notified of renewal request');

  console.log('PRIVATE FILES');
  r = await call('POST', `/api/files?kind=maintenance-photo&ref=${reqId}`, { token: T, raw: png, headers: { 'Content-Type': 'image/png', 'X-File-Name': 'leak.png' } });
  ok(r.status === 201, 'tenant uploads photo to own request');
  const fid = r.data.id;
  r = await call('GET', `/api/files/${fid}`, { token: T });
  ok(r.status === 200 && Buffer.isBuffer(r.data) && r.data.length === png.length, 'owner can download photo');
  r = await call('GET', `/api/files/${fid}`, { token: other.data.token });
  ok(r.status === 403, 'other tenant cannot download it');
  r = await call('GET', `/api/files/${fid}`);
  ok(r.status === 401, 'anonymous cannot download it');
  r = await call('POST', `/api/files?kind=application-doc&ref=application-1`, { token: A, raw: Buffer.from('%PDF-1.4 test'), headers: { 'Content-Type': 'application/pdf', 'X-File-Name': 'payslip.pdf' } });
  ok(r.status === 201, 'admin uploads application document');
  r = await call('POST', `/api/files?kind=lease-contract&ref=${lid}`, { token: A, raw: Buffer.from('%PDF-1.4 contract'), headers: { 'Content-Type': 'application/pdf', 'X-File-Name': 'contract.pdf' } });
  r = await call('POST', `/api/files?kind=lease-contract&ref=${lid}`, { token: A, raw: Buffer.from('%PDF-1.4 contract v2'), headers: { 'Content-Type': 'application/pdf', 'X-File-Name': 'contract2.pdf' } });
  r = await call('GET', `/api/files/by-ref/lease-contract/${lid}`, { token: T });
  ok(r.status === 200 && r.data.toString().includes('v2'), 'tenant can read own lease contract (latest version replaces old)');
  r = await call('GET', `/api/files/by-ref/lease-contract/${lid}`, { token: other.data.token });
  ok(r.status === 403, 'other tenant cannot read lease contract');

  console.log('ADMIN-ONLY AREAS');
  for (const n of ['agents', 'applications', 'outbox']) {
    r = await call('GET', `/api/c/${n}`, { token: T });
    ok(r.status === 403, `tenant cannot read ${n}`);
  }
  r = await call('PUT', '/api/users', { token: T, body: { upserts: [{ id: tenantId, role: 'admin', name: 'x' }] } });
  ok(r.status === 403, 'tenant cannot promote self to admin');
  r = await call('PUT', '/api/users', { token: A, body: { upserts: [{ id: tenantId, role: 'Client', name: 'Juan D. Cruz', phone: '0999 888 7777', location: 'Manila' }] } });
  r = await call('GET', '/api/auth/me', { token: T });
  ok(r.data.user.fullName === 'Juan D. Cruz' && r.data.user.location === 'Manila', 'admin can edit user contact/location');
  r = await call('PUT', '/api/c/agents', { token: A, body: { upserts: [{ id: 'agent-x', name: 'Test Agent', email: 'a@b.com', team: 'North Zone', phone: '123', properties: 2, closedLeases: 1, rating: 4.5, role: 'Agent', status: 'Active', activityDate: '2026-10-10', activity: 'hello' }] } });
  ok(r.status === 200, 'admin creates agent');
  r = await call('PUT', '/api/state/rewards', { token: T, body: { value: { viewedPropertyIds: [pid], reviewedPropertyIds: [], inquirySaved: true } } });
  r = await call('GET', '/api/boot', { token: T });
  ok(r.data.data['sierra-haven-home-rewards'].inquirySaved === true, 'rewards progress persisted per user');
  r = await call('PUT', '/api/settings/technician-availability', { token: A, body: { value: { 'Apex Tech': false } } });
  r = await call('PUT', '/api/settings/technician-roster', { token: A, body: { value: [{ name: 'Apex Tech', skills: ['HVAC'], available: true }] } });
  r = await call('PUT', '/api/settings/bogus', { token: A, body: { value: {} } });
  ok(r.status === 404, 'unknown setting rejected');
  r = await call('PUT', '/api/settings/technician-roster', { token: T, body: { value: [] } });
  ok(r.status === 403, 'tenant cannot change technician roster');
  r = await call('GET', '/api/boot', { token: A });
  ok(r.data.data['haven-maintenance-technician-availability']['Apex Tech'] === false, 'technician availability persisted');
  ok(r.data.data['haven-maintenance-technicians'][0].name === 'Apex Tech', 'technician roster persisted');
  ok(r.data.data['haven-users'].find(u => u.id === tenantId).role === 'Client', 'users view shows role label');

  console.log('DELETE');
  r = await call('PUT', '/api/c/properties', { token: A, body: { deletes: [pid, `lot-${rand}`] } });
  r = await call('GET', '/api/boot');
  ok(!r.data.data['haven-property-listings'].some(p => p.id === pid), 'deleted property disappears for visitors');
  r = await call('PUT', '/api/c/agents', { token: A, body: { deletes: ['agent-x'] } });
  r = await call('PUT', '/api/c/leases', { token: A, body: { deletes: [lid] } });
  r = await call('PUT', '/api/c/maintenance', { token: A, body: { deletes: [reqId] } });
  r = await call('GET', `/api/files/${fid}`, { token: A });
  ok(r.status === 404, 'files are cleaned up when the record is deleted');

  console.log(`\n${pass} passed, ${fail} failed`);
  process.exit(fail ? 1 : 0);
})().catch(e => { console.error(e); process.exit(1); });
