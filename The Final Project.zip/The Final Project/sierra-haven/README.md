# SIERRA HAVEN – Backend (Node.js + Express + Supabase)

Ang `public/index.html` ay ang website mo (landing, login/signup, client portal, tenant dashboard, admin dashboard).
Ang `server.js` ang backend: auth, API, at koneksyon sa Supabase (database + file storage).

## Mabilis na setup (3 hakbang)

**1. I-install**
```bash
npm install
```

**2. Punan ang `.env`** – isa lang ang kulang: `DATABASE_URL`
Supabase Dashboard → pindutin ang **Connect** (taas) → **Connection string → URI** → kopyahin at palitan ang `[YOUR-PASSWORD]` ng database password ng project.
(Nandoon na ang publishable at secret key. Ang `SUPABASE_URL` ay awtomatikong kinukuha sa DATABASE_URL.)
Kung nakalimutan mo ang DB password: Supabase → Project Settings → Database → *Reset database password*.

**3. Patakbuhin**
```bash
npm start
```
Sa unang takbo, **awtomatikong**:
- gagawin ang lahat ng table sa Supabase (users, properties, agents, applications, leases, maintenance, inquiries, outbox, files, …) – hindi mo na kailangang pumasok sa dashboard;
- gagawa ng storage buckets (`property-images` public, `private-documents` private);
- gagawa ng admin account at ipi-print ang email/password sa console (o gamitin ang `ADMIN_EMAIL`/`ADMIN_PASSWORD` sa `.env`).

Buksan ang http://localhost:3000 → mag-login sa admin gamit ang ipinrint na credentials.

> Ilagay rin sa folder na `public/` ang `bg.jpg` at `sierra-haven-mark.png` (ang mga larawang ginagamit ng index.html).

## Paano gumagana

| Gusto mo… | Gawin |
|---|---|
| Mag-upload ng bahay / lupa / condo | Admin → **Properties & Units** → **＋ Add property** (listing type, presyo, kuwarto, sqm, description, maraming photo). Lalabas agad sa landing page at sa dashboard ng lahat ng tenant/client. |
| Makita ang pangalan, contact, location ng nag-register | Admin → **Users & Tenants** |
| Makita kung sino ang interesado / nag-book | Admin → **Inquiries & Bookings** (may tunay na name + contact + status na pwedeng i-update) |
| Bigyan ng lease ang tenant | Admin → **Lease Agreements** → ilagay ang **email na ginamit nila sa pag-register**. Lalabas ang lease, bayad, at contract sa tenant dashboard nila. |
| Maintenance request ng tenant | Ang isinubmit ng tenant ay lalabas sa Admin → **Maintenance** (kasama ang property at pangalan niya). Kapag in-update mo ang status, makikita ng tenant. |
| Technicians | Admin → Maintenance → **Technician availability** → *Add technician* |

Ang mga **tenant/client** ay nagre-register sa website (Sign up: pangalan, email, contact number, location, password).
Ang role ng user ay pwedeng gawing Admin sa **Users & Tenants → Edit**.

## Seguridad
- **Huwag ilagay ang secret key sa index.html / frontend.** Nasa `.env` lang ito (server-side). Ang `.env` ay nasa `.gitignore`.
- **I-rotate ang secret key** (Supabase → Project Settings → API Keys) dahil naipost na ito sa chat, tapos ilagay ang bago sa `.env`.
- Naka-ON ang Row Level Security sa lahat ng table at walang public policy, kaya hindi mababasa ang data gamit ang publishable key. Ang backend lang ang may access.
- Ang passwords ay naka-hash (bcrypt); ang login ay JWT (7 araw), may rate limit ang login/signup.
- Ang private files (application documents, contracts, maintenance photos) ay makukuha lang ng admin at ng may-ari nito.

## Deploy (Render / Railway / VPS)
Ilagay ang laman ng `.env` bilang Environment Variables, `npm install` ang build command, `npm start` ang start command. Siguraduhing naka-`NODE_ENV=production`.

## Test
`npm test` (kailangang tumatakbo ang server; gumagamit ng ADMIN_EMAIL/ADMIN_PASSWORD) – 57 na API checks: auth, permissions, uploads, tenant ↔ admin flow.

## Mga file
```
server.js            routes (auth, boot, collections, tenant, files)
lib/config.js        .env loader
lib/db.js            Postgres pool (Supabase)
lib/migrate.js       auto-create ng tables  (sql/schema.sql)
lib/collections.js   mapping ng records <-> columns, access rules
lib/storage.js       Supabase Storage (may local fallback)
lib/auth.js          signup/login/JWT/admin bootstrap
public/index.html    ang frontend (naka-connect na sa backend)
```
